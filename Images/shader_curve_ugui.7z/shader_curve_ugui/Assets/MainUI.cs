﻿using UnityEngine;
using System.Collections;
using UnityEngine.UI;

public class MainUI : MonoBehaviour {

	public Slider  _A;
	public Slider  _Width;
	public Material m;
	public void OnValueChange(float v){
		m.SetFloat ("_A", v);
	}

	public void OnValueChange2(float v){
		m.SetFloat ("_Width", v*100);
	}
}
